interface CraftingItem {
  label: string;
  icon: string;
  showcase: string;
  description: string;
  materials: string;
}

const craftingItems: CraftingItem[] = [
  {
    label: "[Map](/wiki/The_Map)",
    icon: "https://static.wikia.nocookie.net/99-nights-in-the-forest/images/5/5c/Map_Logo_PNG.png/revision/latest?cb=20250725141944",
    showcase: "https://static.wikia.nocookie.net/99-nights-in-the-forest/images/a/a5/Map_in-game.png/revision/latest?cb=20250625154911",
    description: "Shows a map with information on it. Can be opened anywhere by pressing M on PC or by clicking on the map icon on the top right on mobile.",
    materials: "3 Wood"
  },
  // Old Bed, Bunny Trap, Crafting Bench 2, Sun Dial, Regular Bed ... (add remaining)
  // For example:
  {
    label: "Old Bed",
    icon: "https://static.wikia.nocookie.net/99-nights-in-the-forest/images/4/46/Old_Bed_PNG.png/revision/latest?cb=20250626184223",
    showcase: "https://static.wikia.nocookie.net/99-nights-in-the-forest/images/a/a3/Old_Bed.png/revision/latest?cb=20250626184356",
    description: "Makes the day counter increase by +1.",
    materials: "20 Wood"
  },
  // ... include all fetched
];

const Crafting: React.FC = () => {
  return (
    <div className="page-container">
      <h1>Crafting</h1>
      <p>Crafting is one of the most important mechanics in 99 Nights in the Forest, allowing the player to craft things such as farm plots, beds, and other various items, tools and devices to aid them in their survival.</p>
      <img src="https://static.wikia.nocookie.net/99-nights-in-the-forest/images/2/21/Grinder.png/revision/latest?cb=20250626134103" alt="Grinder" />
      <p>The Grinder, where you can grind materials to craft with them in the Crafting Bench.</p>
      <table className="crafting-table">
        <thead>
          <tr>
            <th>Label</th>
            <th>Icon</th>
            <th>In-Game Showcase</th>
            <th>Description</th>
            <th>Needed Materials</th>
          </tr>
        </thead>
        <tbody>
          {craftingItems.map((item, index) => (
            <tr key={index}>
              <td>{item.label}</td>
              <td><img src={item.icon} alt={item.label} width="50" /></td>
              <td><img src={item.showcase} alt={`${item.label} showcase`} width="50" /></td>
              <td>{item.description}</td>
              <td>{item.materials}</td>
            </tr>
          ))}
        </tbody>
      </table>
      {/* Add badges and tips sections if more data fetched */}
    </div>
  );
};

export default Crafting;