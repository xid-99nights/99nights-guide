const Items: React.FC = () => {
  const sacks = [
    { Items: "Old Sack", "Use(s)": "The Old Sack can store up to 5 items (7 with the Scavenger Class).", "Source(s)": "Spawning into the game" },
    // ... all from fetched
  ];
  const axes = [
    { Items: "Old Axe", "Use(s)": "Takes 13 hits to destroy a tree.", "Source(s)": "Spawning into the game" },
    // ... all
  ];
  // Add arrays for rods, lightSources, weapons, ranged, armor, food, seeds, fuel, misc from fetched data

  return (
    <div className="page-container">
      <h1>Items</h1>
      <p>Items are a core part of 99 Nights in the Forest. These are usable items that players can consume as food, use as crafting materials, or burn as fuel for the Campfire.</p>
      <img src="https://static.wikia.nocookie.net/99-nights-in-the-forest/images/0/0d/Items.png/revision/latest?cb=20250710054224" alt="Items Overview" />
      <section>
        <h2>Sacks</h2>
        <table>
          <thead><tr><th>Items</th><th>Use(s)</th><th>Source(s)</th></tr></thead>
          <tbody>
            {sacks.map((item, i) => (
              <tr key={i}><td>{item.Items}</td><td>{item["Use(s)"]}</td><td>{item["Source(s)"]}</td></tr>
            ))}
          </tbody>
        </table>
      </section>
      <section>
        <h2>Axes</h2>
        <table>
          <thead><tr><th>Items</th><th>Use(s)</th><th>Source(s)</th></tr></thead>
          <tbody>
            {axes.map((item, i) => (
              <tr key={i}><td>{item.Items}</td><td>{item["Use(s)"]}</td><td>{item["Source(s)"]}</td></tr>
            ))}
          </tbody>
        </table>
      </section>
      {/* Add sections for rods, light sources, weapons, ranged, armor, food, seeds, fuel, misc */}
    </div>
  );
};

export default Items;